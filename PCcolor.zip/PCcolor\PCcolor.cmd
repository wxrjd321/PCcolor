@echo off
rem ============================================================
rem  PCcolor - Windows Auto Dark/Light Mode Switcher
rem  Entry: PCcolor settings | status | switch | uninstall | help
rem  Pure ASCII file: no codepage issues in any terminal.
rem ============================================================
setlocal EnableExtensions DisableDelayedExpansion

set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"

set "PS_EXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS_EXE%" set "PS_EXE=powershell.exe"
set "PS_ARGS=-NoProfile -NoLogo -NonInteractive -ExecutionPolicy Bypass"

if /i "%~1"==""     goto help
if /i "%~1"=="help" goto help
if /i "%~1"=="-h"   goto help
if /i "%~1"=="/?"   goto help

if /i "%~1"=="settings"  goto do_settings
if /i "%~1"=="status"    goto do_status
if /i "%~1"=="switch"    goto do_switch
if /i "%~1"=="uninstall" goto do_uninstall

echo [PCcolor] Unknown command: %~1
echo.
goto help

:do_settings
"%PS_EXE%" %PS_ARGS% -File "%ROOT%\scripts\menu.ps1" -Command settings
exit /b %errorlevel%

:do_status
"%PS_EXE%" %PS_ARGS% -File "%ROOT%\scripts\menu.ps1" -Command status
exit /b %errorlevel%

:do_switch
if /i "%~2"=="dark"  goto do_switch_run
if /i "%~2"=="light" goto do_switch_run
echo [PCcolor] Usage: PCcolor switch dark ^| light
exit /b 1
:do_switch_run
"%PS_EXE%" %PS_ARGS% -File "%ROOT%\scripts\apply-theme.ps1" -Mode "%~2"
exit /b %errorlevel%

:do_uninstall
"%PS_EXE%" %PS_ARGS% -File "%ROOT%\scripts\menu.ps1" -Command uninstall
exit /b %errorlevel%

:help
echo PCcolor - Windows Auto Dark/Light Mode Scheduler
echo.
echo   PCcolor settings        Open settings; first run auto-registers scheduled tasks
echo   PCcolor status          Show current theme, config and scheduled task status
echo   PCcolor switch dark     Switch to dark mode immediately
echo   PCcolor switch light    Switch to light mode immediately
echo   PCcolor uninstall       Remove scheduled tasks (stop auto switching)
echo   PCcolor help            Show this help
echo.
echo   Run "PCcolor settings" inside this folder to start first-time setup.
exit /b 0
