﻿<#
.SYNOPSIS
  PCcolor 设置向导 / 交互菜单 / 状态查看 / 卸载 / 应用管理。
.DESCRIPTION
  由 PCcolor.cmd 调用：
    -Command settings    交互设置（首次运行进入向导并自动注册计划任务）
    -Command status      仅打印当前状态
    -Command uninstall   卸载计划任务
  脚本化首次配置（自动化 / 测试用）：
    -LightTime 07:00 -DarkTime 19:00
#>
[CmdletBinding()]
param(
    [ValidateSet('settings', 'status', 'uninstall')]
    [string]$Command = 'settings',

    [string]$LightTime,
    [string]$DarkTime,
    [switch]$Yes
)

$ErrorActionPreference = 'Stop'

$ScriptDir   = $PSScriptRoot
$ConfigPath  = Join-Path $ScriptDir 'config.json'
$LogPath     = Join-Path $ScriptDir 'logs\switch.log'
$ApplyPs1    = Join-Path $ScriptDir 'apply-theme.ps1'
$RegisterPs1 = Join-Path $ScriptDir 'register-tasks.ps1'
$AppsList    = Join-Path $ScriptDir 'apps.list'
$TaskNames   = @('PCcolor-Light', 'PCcolor-Dark')

try { Import-Module ScheduledTasks -ErrorAction Stop } catch { }

# ---------------------------------------------------------------- 基础函数
function Get-DefaultConfig {
    [pscustomobject]@{
        light_time = '07:00'
        dark_time  = '19:00'
        installed  = $false
    }
}

function Read-Config {
    if (Test-Path -LiteralPath $ConfigPath) {
        try {
            $cfg = (Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8) | ConvertFrom-Json
            if ($cfg -is [psobject]) { return $cfg }
        } catch { }
    }
    return Get-DefaultConfig
}

function Save-Config([pscustomobject]$cfg) {
    $dir = Split-Path -Path $ConfigPath -Parent
    if (-not (Test-Path -LiteralPath $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }
    $cfg | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $ConfigPath -Encoding UTF8
}

function Get-CurrentTheme {
    try {
        $v = (Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -Name AppsUseLightTheme -ErrorAction Stop).AppsUseLightTheme
    } catch { return 'unknown' }
    if ($null -eq $v) { return 'unknown' }
    if ([int]$v -eq 0) { return 'dark' }
    return 'light'
}

function Get-TaskInfo {
    $result = [ordered]@{}
    foreach ($name in $TaskNames) {
        try {
            $task = Get-ScheduledTask -TaskName $name -ErrorAction Stop
            $info = Get-ScheduledTaskInfo -TaskName $name -ErrorAction SilentlyContinue
            $actionText = ($task.Actions | ForEach-Object { "{0} {1}" -f $_.Execute, $_.Arguments }) -join ' '
            $result[$name] = [pscustomobject]@{
                Exists  = $true
                State   = [string]$task.State
                NextRun = $info.NextRunTime
                Action  = $actionText
            }
        } catch {
            $result[$name] = [pscustomobject]@{ Exists = $false; State = ''; NextRun = $null; Action = '' }
        }
    }
    return $result
}

function Get-NextSwitch([string]$lightTime, [string]$darkTime) {
    $now = Get-Date
    $lt  = [datetime]::Today + [timespan]::Parse($lightTime)
    $dt  = [datetime]::Today + [timespan]::Parse($darkTime)
    if ($now -lt $lt) { return [pscustomobject]@{ Time = $lt; Mode = 'light'; Label = '浅色' } }
    if ($now -lt $dt) { return [pscustomobject]@{ Time = $dt; Mode = 'dark';  Label = '深色' } }
    return [pscustomobject]@{ Time = $lt.AddDays(1); Mode = 'light'; Label = '浅色' }
}

function Register-Tasks([string]$lt, [string]$dt) {
    & $RegisterPs1 -LightTime $lt -DarkTime $dt
    if ($LASTEXITCODE -ne 0) { return $false }
    return $true
}

function Unregister-Tasks {
    & $RegisterPs1 -Uninstall
    if ($LASTEXITCODE -ne 0) { return $false }
    return $true
}

function Apply-Theme([string]$mode) {
    & $ApplyPs1 -Mode $mode
    if ($LASTEXITCODE -ne 0) { return $false }
    return $true
}

function Read-TimeInput([string]$label, [string]$default) {
    while ($true) {
        $input = Read-Host ("  请输入{0}时间（24小时制 HH:mm，回车默认 {1}）" -f $label, $default)
        if ([string]::IsNullOrWhiteSpace($input)) { return $default }
        $input = $input.Trim()
        if ($input -match '^([0-9]|0[0-9]|1[0-9]|2[0-3]):([0-5][0-9])$') {
            return ('{0:d2}:{1}' -f [int]$matches[1], $matches[2])
        }
        Write-Host '    格式无效，请使用 24 小时制 HH:mm（例如 07:00 或 19:30）' -ForegroundColor Yellow
    }
}

# ---------------------------------------------------------------- 应用管理
function Get-AppEntries {
    if (-not (Test-Path -LiteralPath $AppsList)) { return @() }
    return @(Get-Content -LiteralPath $AppsList -ErrorAction SilentlyContinue |
        Where-Object { $_ -match '\S' -and $_ -notmatch '^\s*#' })
}

function Show-AppEntries {
    $entries = Get-AppEntries
    if ($entries.Count -eq 0) {
        Write-Host '    （空）' -ForegroundColor DarkGray
    } else {
        for ($i = 0; $i -lt $entries.Count; $i++) {
            $p = $entries[$i] -split '\|', 2
            $path = if ($p.Count -gt 1) { $p[1].Trim() } else { '（切换时自动解析）' }
            Write-Host ("    {0}. {1}  ->  {2}" -f ($i + 1), $p[0].Trim(), $path)
        }
    }
}

function Add-AppEntry([string]$name, [string]$path) {
    $name = $name.Trim()
    if ($name -match '(?i)\.exe$') { $name = $name -replace '(?i)\.exe$', '' }
    if (-not $name) { Write-Host '  进程名不能为空。' ; return $false }

    foreach ($e in (Get-AppEntries)) {
        if (($e -split '\|', 2)[0].Trim() -ieq $name) {
            Write-Host ("  {0} 已在列表中。" -f $name) -ForegroundColor Yellow
            return $false
        }
    }
    if ($name -ieq 'explorer') {
        Write-Host '  提示：任务栏/资源管理器会随切换自动刷新，通常无需添加。' -ForegroundColor Yellow
    }

    if ($path) {
        $path = $path.Trim().Trim('"')
        if (-not (Test-Path -LiteralPath $path)) {
            Write-Host '  路径不存在，已按“切换时自动解析”保存。' -ForegroundColor Yellow
            $path = ''
        }
    }
    $line = $name
    if ($path) { $line = $name + '|' + $path }
    Add-Content -LiteralPath $AppsList -Value $line -Encoding UTF8
    Write-Host ("  已添加：{0}" -f $line) -ForegroundColor Green
    return $true
}

function Remove-AppEntry([int]$index) {
    $entries = Get-AppEntries
    if ($index -lt 1 -or $index -gt $entries.Count) { return $false }
    $removed = $entries[$index - 1]

    $header = @()
    if (Test-Path -LiteralPath $AppsList) {
        $header = @(Get-Content -LiteralPath $AppsList | Where-Object { $_ -match '^\s*#' })
    }
    if ($header.Count -eq 0) {
        $header = @('# PCcolor 自动重启应用列表：进程名[|程序路径]，主题切换时自动重启')
    }
    $kept = @()
    for ($i = 0; $i -lt $entries.Count; $i++) {
        if ($i -ne ($index - 1)) { $kept += $entries[$i] }
    }
    Set-Content -LiteralPath $AppsList -Value $header -Encoding UTF8
    if ($kept.Count -gt 0) { Add-Content -LiteralPath $AppsList -Value $kept -Encoding UTF8 }
    Write-Host ("  已移除：{0}" -f $removed) -ForegroundColor Green
    return $true
}

function Add-AppFromRunning {
    $procs = @(Get-Process | Where-Object { $_.MainWindowTitle -and $_.Id -ne $PID } | Sort-Object ProcessName)
    if ($procs.Count -eq 0) { Write-Host '  没有找到带窗口的运行中应用。' ; return }
    Write-Host '  当前运行中的应用：'
    $n = 0
    foreach ($p in $procs) {
        if ($n -ge 40) { break }
        $n++
        $title = $p.MainWindowTitle
        if ($title.Length -gt 40) { $title = $title.Substring(0, 40) + '...' }
        Write-Host ("    [{0}] {1} — {2}" -f $n, $p.ProcessName, $title)
    }
    $sel = (Read-Host '  输入编号添加（回车取消）').Trim()
    if (-not $sel) { return }
    $idx = 0
    if (-not [int]::TryParse($sel, [ref]$idx)) { Write-Host '  无效编号。' ; return }
    if ($idx -lt 1 -or $idx -gt $n) { Write-Host '  编号超出范围。' ; return }
    $p = $procs[$idx - 1]
    $path = ''
    try { $path = $p.Path } catch { }
    Add-AppEntry $p.ProcessName $path
}

function Add-AppManual {
    $name = (Read-Host '  进程名（如 notepad，可不带 .exe）').Trim()
    if (-not $name) { return }
    $path = (Read-Host '  程序完整路径（可留空，切换时自动解析）').Trim()
    Add-AppEntry $name $path
}

function Start-AppManager {
    while ($true) {
        Write-Host ''
        Write-Host '  ---- 自动重启应用管理 ----' -ForegroundColor DarkCyan
        Write-Host '  主题切换时会自动关闭并重新打开列表中的应用，使其立刻应用新主题。'
        Write-Host '  注意：被配置的应用会在切换时被关闭，未保存的内容可能丢失，请谨慎添加。'
        Write-Host '  任务栏/开始菜单等系统组件会随切换自动刷新，无需加入列表。'
        Write-Host '  当前列表：'
        Show-AppEntries
        Write-Host '  [1] 从当前运行的应用中添加'
        Write-Host '  [2] 手动输入添加'
        Write-Host '  [3] 移除应用'
        Write-Host '  [0] 返回上级'
        $sel = (Read-Host '  请选择').Trim()
        switch ($sel) {
            '1' { Add-AppFromRunning }
            '2' { Add-AppManual }
            '3' {
                $entries = Get-AppEntries
                if ($entries.Count -eq 0) {
                    Write-Host '  列表为空，无可移除。'
                } else {
                    $num = (Read-Host '  输入要移除的编号（回车取消）').Trim()
                    $idx = 0
                    if (-not $num) { }
                    elseif ([int]::TryParse($num, [ref]$idx) -and $idx -ge 1 -and $idx -le $entries.Count) {
                        Remove-AppEntry $idx
                    } else { Write-Host '  无效编号。' }
                }
            }
            '0' { return }
            default { Write-Host '  无效选择。' }
        }
    }
}

# ---------------------------------------------------------------- 界面
function Show-Status {
    $cfg   = Read-Config
    $theme = Get-CurrentTheme
    $tasks = Get-TaskInfo
    $registered = ($tasks['PCcolor-Light'].Exists -and $tasks['PCcolor-Dark'].Exists)

    Write-Host ''
    Write-Host '  ============================================================' -ForegroundColor DarkCyan
    Write-Host '   PCcolor — Windows 自动深浅色模式' -ForegroundColor Cyan
    Write-Host '  ============================================================' -ForegroundColor DarkCyan

    $themeText = switch ($theme) { 'dark' { '深色 (dark)' } 'light' { '浅色 (light)' } default { '未知' } }
    Write-Host ("  当前系统主题 : {0}" -f $themeText)

    if ($registered) {
        Write-Host ("  计划配置     : 每天 {0} 切浅色 | {1} 切深色" -f $cfg.light_time, $cfg.dark_time)
    } else {
        Write-Host '  计划配置     : 未注册（运行 PCcolor settings 完成首次设置）' -ForegroundColor Yellow
    }

    if ($registered) {
        $next = $null
        try { $next = Get-NextSwitch $cfg.light_time $cfg.dark_time } catch { }
        if ($next) {
            $delta = $next.Time - (Get-Date)
            if ($delta.TotalSeconds -le 0) { $eta = '即将执行' }
            else { $eta = ('{0} 小时 {1} 分后' -f [int][math]::Floor($delta.TotalHours), $delta.Minutes) }
            Write-Host ("  下次切换     : {0} -> {1}（{2}）" -f $next.Time.ToString('MM-dd HH:mm'), $next.Label, $eta)
        }
    } else {
        foreach ($n in $TaskNames) {
            if (-not $tasks[$n].Exists) {
                Write-Host ("    - {0} : 未注册" -f $n) -ForegroundColor DarkGray
            }
        }
    }

    $appEntries = Get-AppEntries
    if ($appEntries.Count -gt 0) {
        $names = ($appEntries | ForEach-Object { ($_ -split '\|', 2)[0].Trim() }) -join ', '
        Write-Host ("  自动重启应用 : {0} 个（{1}）" -f $appEntries.Count, $names)
    } else {
        Write-Host '  自动重启应用 : 未配置（菜单 [6] 可添加）' -ForegroundColor DarkGray
    }

    Write-Host '  运行模型     : 仅计划任务触发，无后台常驻进程，空闲占用为 0'

    if (Test-Path -LiteralPath $LogPath) {
        $last = Get-Content -LiteralPath $LogPath -Tail 2 -ErrorAction SilentlyContinue
        if ($last) {
            Write-Host '  最近日志     :'
            foreach ($l in $last) { Write-Host ("    {0}" -f $l) -ForegroundColor DarkGray }
        }
    }
    Write-Host ''
}

function Start-FirstRun {
    Write-Host ''
    Write-Host '  欢迎使用 PCcolor —— Windows 自动深浅色模式' -ForegroundColor Cyan
    Write-Host '  首次运行：设置切换时间，随后自动注册为 Windows 计划任务。'
    Write-Host '  （无后台常驻进程；切换无窗口、不打扰工作）'
    Write-Host ''

    $lt = Read-TimeInput '浅色模式' '07:00'
    $dt = Read-TimeInput '深色模式' '19:00'
    while ($lt -eq $dt) {
        Write-Host '    浅色与深色时间不能相同。' -ForegroundColor Yellow
        $dt = Read-TimeInput '深色模式' '19:00'
    }

    Write-Host ''
    Write-Host ("  配置确认：每天 {0} 切换到浅色，每天 {1} 切换到深色" -f $lt, $dt) -ForegroundColor Green
    $ok = Read-Host '  确认并注册计划任务？[Y/n]'
    if ($ok -and $ok.Trim().ToLower() -eq 'n') {
        Write-Host '  已取消，未做任何更改。'
        return
    }

    Write-Host '  正在注册 Windows 计划任务 ...'
    if (-not (Register-Tasks $lt $dt)) {
        Write-Host '  注册失败，请根据上方错误信息处理后重试。' -ForegroundColor Red
        return
    }
    Save-Config ([pscustomobject]@{
        light_time   = $lt
        dark_time    = $dt
        installed    = $true
        installed_at = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    })
    Write-Host '  注册完成。计划任务已生效，后台无常驻进程。' -ForegroundColor Green

    $nowT = (Get-Date).TimeOfDay
    $ltT  = [timespan]::Parse($lt)
    $dtT  = [timespan]::Parse($dt)
    $mode = 'light'
    if ($nowT -ge $dtT -or $nowT -lt $ltT) { $mode = 'dark' }
    $label = if ($mode -eq 'dark') { '深色' } else { '浅色' }
    $ans = Read-Host ("  是否立即应用当前时段应处的模式（{0}）？[Y/n]" -f $label)
    if (-not ($ans -and $ans.Trim().ToLower() -eq 'n')) {
        if (Apply-Theme $mode) { Write-Host ("  已切换到{0}。" -f $label) -ForegroundColor Green }
    }

    $ans2 = Read-Host '  是否现在配置“切换时自动重启的应用”？[y/N]'
    if ($ans2 -and $ans2.Trim().ToLower() -eq 'y') { Start-AppManager }
}

function Start-Menu {
    while ($true) {
        $cfg = Read-Config
        Show-Status
        Write-Host ("  [1] 修改浅色模式时间      （当前 {0}）" -f $cfg.light_time)
        Write-Host ("  [2] 修改深色模式时间      （当前 {0}）" -f $cfg.dark_time)
        Write-Host '  [3] 立即切换深浅色'
        Write-Host '  [4] 重新注册计划任务'
        Write-Host '  [5] 卸载计划任务（停止自动切换）'
        Write-Host '  [6] 管理自动重启的应用列表'
        Write-Host '  [0] 退出'
        $sel = (Read-Host '  请选择').Trim()

        switch ($sel) {
            '1' {
                $t = Read-TimeInput '浅色模式' $cfg.light_time
                if ($t -eq $cfg.dark_time) {
                    Write-Host '    不能与深色时间相同。' -ForegroundColor Yellow
                } else {
                    $cfg.light_time = $t
                    Save-Config $cfg
                    Write-Host '  时间已更新，正在重新注册计划任务 ...'
                    if (Register-Tasks $cfg.light_time $cfg.dark_time) {
                        Write-Host '  完成。' -ForegroundColor Green
                    }
                }
            }
            '2' {
                $t = Read-TimeInput '深色模式' $cfg.dark_time
                if ($t -eq $cfg.light_time) {
                    Write-Host '    不能与浅色时间相同。' -ForegroundColor Yellow
                } else {
                    $cfg.dark_time = $t
                    Save-Config $cfg
                    Write-Host '  时间已更新，正在重新注册计划任务 ...'
                    if (Register-Tasks $cfg.light_time $cfg.dark_time) {
                        Write-Host '  完成。' -ForegroundColor Green
                    }
                }
            }
            '3' {
                $m = (Read-Host '  输入 d 切换深色，l 切换浅色').Trim().ToLower()
                if ($m -eq 'd') {
                    if (Apply-Theme 'dark') { Write-Host '  已切换到深色。' -ForegroundColor Green }
                } elseif ($m -eq 'l') {
                    if (Apply-Theme 'light') { Write-Host '  已切换到浅色。' -ForegroundColor Green }
                } else {
                    Write-Host '  已取消。'
                }
            }
            '4' {
                Write-Host '  正在重新注册计划任务 ...'
                if (Register-Tasks $cfg.light_time $cfg.dark_time) {
                    $cfg.installed = $true
                    Save-Config $cfg
                    Write-Host '  完成。' -ForegroundColor Green
                }
            }
            '5' {
                $c = (Read-Host '  确认卸载计划任务并停止自动切换？[y/N]').Trim().ToLower()
                if ($c -eq 'y') {
                    if (Unregister-Tasks) {
                        if (Test-Path -LiteralPath $ConfigPath) {
                            $cfg.installed = $false
                            Save-Config $cfg
                        }
                        Write-Host '  已卸载。可随时运行 PCcolor settings 恢复。' -ForegroundColor Green
                    }
                }
            }
            '6' { Start-AppManager }
            '0' { return }
            default { Write-Host '  无效选择，请重新输入。' -ForegroundColor DarkGray }
        }
        Write-Host ''
    }
}

# ---------------------------------------------------------------- 主流程
try {
    if ($LightTime -and $DarkTime) {
        if ($LightTime -eq $DarkTime) { throw '浅色与深色时间不能相同' }
        if (-not (Register-Tasks $LightTime $DarkTime)) { exit 1 }
        Save-Config ([pscustomobject]@{
            light_time   = $LightTime
            dark_time    = $DarkTime
            installed    = $true
            installed_at = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
        })
        Write-Host ("  已注册：每天 {0} 切浅色 / {1} 切深色" -f $LightTime, $DarkTime) -ForegroundColor Green
        exit 0
    }

    switch ($Command) {
        'status' { Show-Status }
        'uninstall' {
            $c = 'n'
            if (-not $Yes) { $c = (Read-Host '  确认卸载 PCcolor 计划任务？[y/N]').Trim().ToLower() }
            if ($Yes -or $c -eq 'y') {
                if (Unregister-Tasks) {
                    if (Test-Path -LiteralPath $ConfigPath) {
                        $cfg = Read-Config
                        $cfg.installed = $false
                        Save-Config $cfg
                    }
                    Write-Host '  已卸载。' -ForegroundColor Green
                } else { exit 1 }
            } else {
                Write-Host '  已取消。'
            }
        }
        default {
            $cfg   = Read-Config
            $tasks = Get-TaskInfo
            $fresh = (-not $cfg.installed -and -not $tasks['PCcolor-Light'].Exists -and -not $tasks['PCcolor-Dark'].Exists)
            if ($fresh) { Start-FirstRun } else { Start-Menu }
        }
    }
}
catch {
    Write-Host ''
    Write-Host ("  [错误] {0}" -f $_.Exception.Message) -ForegroundColor Red
    exit 1
}
