﻿<#
.SYNOPSIS
  PCcolor 计划任务注册 / 卸载。
.DESCRIPTION
  注册两个每日计划任务（无常驻进程、不轮询）：
    PCcolor-Light : 每天 LightTime 切到浅色
    PCcolor-Dark  : 每天 DarkTime  切到深色
  执行引擎：wscript.exe（无控制台窗口）+ run-hidden.vbs
            -> PowerShell -WindowStyle Hidden -> apply-theme.ps1
  任务以当前用户、交互式登录、Limited 权限运行（无需管理员、不弹 UAC）。
  用法：
    register-tasks.ps1 -LightTime 07:00 -DarkTime 19:00
    register-tasks.ps1 -Uninstall
#>
[CmdletBinding()]
param(
    [string]$LightTime,
    [string]$DarkTime,
    [switch]$Uninstall
)

$ErrorActionPreference = 'Stop'

$ScriptDir = $PSScriptRoot
$Root      = Split-Path -Path $ScriptDir -Parent
$VbsPath   = Join-Path $Root 'run-hidden.vbs'
$TaskNames = @('PCcolor-Light', 'PCcolor-Dark')

try {
    try { Import-Module ScheduledTasks -ErrorAction Stop } catch { }
    if (-not (Get-Command Register-ScheduledTask -ErrorAction SilentlyContinue)) {
        throw '无法使用 ScheduledTasks 模块：Windows 任务计划程序服务可能被禁用。'
    }
    if (-not (Test-Path -LiteralPath $VbsPath)) {
        throw ("找不到无窗口启动器：{0}" -f $VbsPath)
    }

    if ($Uninstall) {
        foreach ($n in $TaskNames) {
            Unregister-ScheduledTask -TaskName $n -Confirm:$false -ErrorAction SilentlyContinue
            Write-Host ("  [OK] 已卸载计划任务 {0}" -f $n)
        }
        exit 0
    }

    foreach ($t in @($LightTime, $DarkTime)) {
        if ([string]::IsNullOrWhiteSpace($t) -or $t -notmatch '^([01][0-9]|2[0-3]):[0-5][0-9]$') {
            throw ("时间格式无效：{0}（应为 HH:mm，例如 07:00）" -f $t)
        }
    }
    if ($LightTime -eq $DarkTime) { throw '浅色与深色时间不能相同' }

    # ---- 注册两个每日任务 ---------------------------------------------------
    $plan = @(
        [pscustomobject]@{ Name = 'PCcolor-Light'; Mode = 'light'; Time = $LightTime; Desc = 'PCcolor 定时切换到浅色模式' },
        [pscustomobject]@{ Name = 'PCcolor-Dark';  Mode = 'dark';  Time = $DarkTime;  Desc = 'PCcolor 定时切换到深色模式' }
    )

    foreach ($p in $plan) {
        # wscript 为 GUI 子系统进程，本身无控制台；内部以隐藏窗口方式启动 PowerShell
        $action = New-ScheduledTaskAction -Execute 'wscript.exe' -Argument ("//B //Nologo `"{0}`" {1}" -f $VbsPath, $p.Mode)

        $at = [datetime]::ParseExact($p.Time, 'HH:mm', [System.Globalization.DateTimeFormatInfo]::InvariantInfo)
        if ($at -lt (Get-Date)) { $at = $at.AddDays(1) }   # 仅取时分，避开过去日期边界
        $trigger = New-ScheduledTaskTrigger -Daily -At $at
        $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 5)

        Register-ScheduledTask -TaskName $p.Name -Action $action -Trigger $trigger -Settings $settings -Description $p.Desc -Force | Out-Null

        if (-not (Get-ScheduledTask -TaskName $p.Name -ErrorAction SilentlyContinue)) {
            throw ("注册后校验失败：{0}" -f $p.Name)
        }
        Write-Host ("  [OK] {0}：每天 {1} 执行 -> {2}（wscript 无窗口 + PowerShell 隐藏窗口）" -f $p.Name, $p.Time, $p.Mode)
    }

    Write-Host '  计划任务注册完成：无常驻进程，空闲内存占用为 0。'
    exit 0
}
catch {
    Write-Host ''
    Write-Host ("  [错误] {0}" -f $_.Exception.Message) -ForegroundColor Red
    exit 1
}
