﻿<#
.SYNOPSIS
  PCcolor 主题切换核心。
.DESCRIPTION
  1. 写入 HKCU Personalize 注册表（AppsUseLightTheme / SystemUsesLightTheme）
  2. 广播 WM_SETTINGCHANGE (ImmersiveColorSet)，系统组件与大多数应用即时刷新
  3. 按 apps.list 自动重启配置的应用，使其立刻应用新主题
  用法：apply-theme.ps1 -Mode dark|light
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('dark', 'light')]
    [string]$Mode
)

$ErrorActionPreference = 'Stop'

$ScriptDir = $PSScriptRoot
$LogDir    = Join-Path $ScriptDir 'logs'
$LogFile   = Join-Path $LogDir 'switch.log'
$AppsList  = Join-Path $ScriptDir 'apps.list'

function Write-Log([string]$msg) {
    try {
        if (-not (Test-Path -LiteralPath $LogDir)) {
            New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
        }
        $line = '{0} [apply-theme] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $msg
        Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
    } catch { }
}

function Restart-ConfiguredApps {
    if (-not (Test-Path -LiteralPath $AppsList)) { return }
    $entries = @(Get-Content -LiteralPath $AppsList -ErrorAction SilentlyContinue |
        Where-Object { $_ -match '\S' -and $_ -notmatch '^\s*#' })
    if ($entries.Count -eq 0) { return }

    foreach ($line in $entries) {
        $parts = $line -split '\|', 2
        $procName = $parts[0].Trim()
        $exePath  = ''
        if ($parts.Count -gt 1) { $exePath = $parts[1].Trim() }
        if ($procName -match '(?i)\.exe$') { $procName = $procName -replace '(?i)\.exe$', '' }
        if (-not $procName) { continue }

        $procs = @(Get-Process -Name $procName -ErrorAction SilentlyContinue)
        if ($procs.Count -eq 0) {
            Write-Log ("app skip (not running): {0}" -f $procName)
            continue
        }

        if (-not $exePath) {
            foreach ($p in $procs) {
                try { $exePath = $p.Path } catch { }
                if ($exePath) { break }
            }
        }
        if (-not $exePath -or -not (Test-Path -LiteralPath $exePath)) {
            Write-Log ("app skip (exe path unknown): {0}" -f $procName)
            continue
        }

        # graceful close first, then force after 3s (documented data-loss risk)
        foreach ($p in $procs) { try { $null = $p.CloseMainWindow() } catch { } }
        $deadline = (Get-Date).AddSeconds(3)
        while ((Get-Date) -lt $deadline) {
            if (@(Get-Process -Name $procName -ErrorAction SilentlyContinue).Count -eq 0) { break }
            Start-Sleep -Milliseconds 300
        }
        $left = @(Get-Process -Name $procName -ErrorAction SilentlyContinue)
        foreach ($p in $left) { try { $p.Kill() } catch { } }
        if ($left.Count -gt 0) { Start-Sleep -Milliseconds 300 }

        try {
            Start-Process -FilePath $exePath -WorkingDirectory (Split-Path -Path $exePath -Parent)
            Write-Log ("app restarted: {0} ({1})" -f $procName, $exePath)
        } catch {
            Write-Log ("app restart failed: {0} ({1})" -f $procName, $_.Exception.Message)
        }
    }
}

$KeyPath = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize'
$value  = if ($Mode -eq 'dark') { 0 } else { 1 }

try {
    $before = (Get-ItemProperty -Path $KeyPath -Name AppsUseLightTheme -ErrorAction SilentlyContinue).AppsUseLightTheme
    if ($null -eq $before) { $before = '<none>' }

    Set-ItemProperty -Path $KeyPath -Name AppsUseLightTheme  -Value $value -Type DWord -Force
    Set-ItemProperty -Path $KeyPath -Name SystemUsesLightTheme -Value $value -Type DWord -Force
    Write-Log ("mode={0} AppsUseLightTheme {1} -> {2} (SystemUsesLightTheme synced)" -f $Mode, $before, $value)

    if (-not ('PCcolor.Win32' -as [type])) {
        Add-Type -Namespace 'PCcolor' -Name 'Win32' -MemberDefinition @'
[DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
public static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, UIntPtr wParam, string lParam, uint fuFlags, uint uTimeout, out UIntPtr lpdwResult);
'@
    }

    $hwndBroadcast   = [IntPtr]0xffff
    $wmSettingChange = 0x1A
    $smtoAbortIfHung = 0x0002
    $result = [UIntPtr]::Zero

    [PCcolor.Win32]::SendMessageTimeout($hwndBroadcast, $wmSettingChange, [UIntPtr]::Zero, 'ImmersiveColorSet', $smtoAbortIfHung, 5000, [ref]$result) | Out-Null
    Start-Sleep -Milliseconds 150
    [PCcolor.Win32]::SendMessageTimeout($hwndBroadcast, $wmSettingChange, [UIntPtr]::Zero, 'ImmersiveColorSet', $smtoAbortIfHung, 5000, [ref]$result) | Out-Null
    Write-Log 'WM_SETTINGCHANGE(ImmersiveColorSet) broadcast sent'

    Restart-ConfiguredApps

    exit 0
}
catch {
    Write-Log ("ERROR: {0}" -f $_)
    exit 1
}
