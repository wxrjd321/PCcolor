' ============================================================
'  PCcolor hidden launcher for scheduled tasks (fallback path)
'  Used only when scripts\bin\applytheme.exe is unavailable.
'  wscript.exe has no console window at all.
'  Usage: wscript.exe //B //Nologo run-hidden.vbs <dark|light>
' ============================================================
Option Explicit

Dim fso, shell, dir, ps1, mode, cmd

If WScript.Arguments.Count = 0 Then
    WScript.Quit 2
End If

mode = LCase(Trim(WScript.Arguments(0)))
If mode <> "dark" And mode <> "light" Then
    WScript.Quit 2
End If

Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

dir = fso.GetParentFolderName(WScript.ScriptFullName)
ps1 = fso.BuildPath(dir, "scripts\apply-theme.ps1")

' Window style 0 = hidden, wait = False -> fully silent, no console flash
cmd = "powershell.exe -NoProfile -NoLogo -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & ps1 & """ -Mode " & mode
shell.Run cmd, 0, False

WScript.Quit 0
